// DataDisplay.js

import React, { useState } from 'react';

const DataDisplay = () => {
  // Estado para almacenar los datos que se mostrarán
  const [data, setData] = useState(null);

  // Función para manejar el clic del botón
  const handleButtonClick = async() => {
    // Simulación de obtención de datos (puedes reemplazarlo con una llamada a la API)

      // Simulamos una llamada a la API que devuelve datos después de 1 segundo
      try {        
        const respuesta = await fetch('http://localhost:8000/data')
        const data =  await respuesta.json()
        setData(data)
        console.log(data)
      } catch (error) {
        console.log(error);
      }

  };

  return (
    <div style={{display:'flex',justifyContent:'center'}}>
      <button onClick={handleButtonClick}>Mostrar Datos</button>
      {data && (
        <div>
          {/* Puedes mostrar los datos en un elemento de texto o en un alert */}
          <p>{data.name}</p>
          <p>{data.carne}</p>
          {/* Opción con alert: descomentar la línea siguiente */}
          {/* <button onClick={() => alert(data)}>Mostrar en Alert</button> */}
        </div>
      )}
    </div>
  );
};

export default DataDisplay;
