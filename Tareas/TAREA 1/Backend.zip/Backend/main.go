package main

import (
	"encoding/json"
	"log"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
)

type Student struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Carne string `json:"carne"`
}

func main() {
	app := fiber.New()

	app.Use(cors.New())

	app.Use(cors.New(cors.Config{
		AllowOrigins: "*",
		AllowMethods: "GET,POST,PUT,DELETE",
		AllowHeaders: "Origin, Content-Type, Accept",
	}))

	app.Get("/", func(c *fiber.Ctx) error {
		return c.SendString("Hello, World!")
	})

	app.Get("/ping", func(c *fiber.Ctx) error {
		return c.SendString("pong")
	})

	app.Get("/data", func(c *fiber.Ctx) error {
		student := Student{
			ID:    1,
			Name:  "Cristian Fernando Hernandez Tello",
			Carne: "202010905",
		}

		jsonData, err := json.Marshal(student)
		if err != nil {
			log.Println("Error al convertir a JSON:", err)
			return c.Status(fiber.StatusInternalServerError).SendString("Error interno del servidor")
		}
		c.Set("Content-Type", "application/json")
		return c.Send(jsonData)

	})

	log.Fatal(app.Listen(":8000"))
}
